## Time Table Scheduling Implementation

Files Included
------------------------
--INFO_6205_Team10(.zip)
--this README file
--Analysis.xlsx
--INFO_6205_team10.docx

Inside the Project Files
------------------------
 

--Source Packages
--Test Packages
--Dependencies
--Test Dependencies
--Java Dependencies
--Project Files

Source Package
--Properties has log4j.properties
--geneticalgorithm has ClassSchedule.java,Data.java,GeneticAlgorithm.java,Main.java,Population.java
--geneticalgorithm.domain has Class.java,Course.java,Department.java,MeetingTime.java,Professor.java,Room.java
--utilities has StopWatch.java

Test Package has TestJava.java INFO_6205_Team10\INFO_6205_Team10\target\site\apidocs 


